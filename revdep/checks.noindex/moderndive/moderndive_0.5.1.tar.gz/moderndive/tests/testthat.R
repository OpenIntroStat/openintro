library(testthat)
library(moderndive)

test_check("moderndive")
